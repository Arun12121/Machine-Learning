import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
import math
import joblib
    

if __name__ == "__main__":
    train_X = np.genfromtxt("train_X.csv", delimiter=',', skip_header=1)
    train_Y = np.genfromtxt("train_Y.csv", delimiter=',')
    c = 22
    validation_split_percent = 20
    nofobs = int(math.floor((100 - validation_split_percent) / 100.0 * len(train_X)))
    X = train_X[:nofobs]
    Y = train_Y[:nofobs]
    Xv = train_X[nofobs:]
    Yv = train_Y[nofobs:]
    clf = make_pipeline(StandardScaler(), SVC(C = c))
    clf.fit(train_X, train_Y)
    joblib.dump(clf, 'model.pkl')
    print(accuracy_score(Yv, clf.predict(Xv)))